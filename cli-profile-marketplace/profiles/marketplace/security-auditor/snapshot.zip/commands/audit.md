# /audit Command

Perform a comprehensive security audit of the provided code.

## Instructions

1. Scan for common vulnerability patterns
2. Check against OWASP Top 10
3. Review authentication and authorization logic
4. Check for sensitive data handling issues
5. Look for injection vulnerabilities
6. Assess cryptographic usage

## Severity Levels

- **Critical**: Immediately exploitable, high impact
- **High**: Exploitable with some conditions, significant impact
- **Medium**: Requires specific conditions, moderate impact  
- **Low**: Minimal impact or hard to exploit

Always provide:
- What the vulnerability is
- How it could be exploited
- What the impact would be
- How to fix it securely
