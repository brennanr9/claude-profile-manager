# /typing Command

Add or improve type hints for Python code.

## Instructions

1. Analyze the code structure and data flow
2. Add appropriate type hints to all functions
3. Use modern typing features (Python 3.10+)
4. Consider using TypedDict for complex dicts
5. Add generic types where appropriate
6. Use Protocol for structural subtyping

## Type Hint Best Practices

- Use `|` instead of `Union` (3.10+)
- Use `list[T]` instead of `List[T]` (3.9+)
- Prefer `Sequence` over `list` for read-only params
- Use `Mapping` for dict-like read-only params
- Add `TypeVar` for generic functions
- Consider `overload` for functions with different signatures
