# Git Workflow Profile

Follow conventional commits format. Never force-push to shared branches. Always create feature branches for new work.
