Before pushing, verify:
- The branch is not main/master (warn if pushing directly)
- All tests pass (run the project's test command)
- The branch is up to date with the remote base branch
