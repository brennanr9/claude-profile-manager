# /readme

Generate a comprehensive README.md including: title, description, features, installation, usage, configuration, and license.
