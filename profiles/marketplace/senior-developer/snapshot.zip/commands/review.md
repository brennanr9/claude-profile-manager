# /review Command

Review the provided code as a senior engineer would during a pull request review.

## Instructions

1. First, understand the overall purpose and context of the code
2. Check for correctness, bugs, and edge cases
3. Evaluate security implications
4. Consider performance characteristics  
5. Assess code quality and maintainability
6. Prioritize findings by severity

## Output Format

Provide feedback in this structure:
- Summary (1-2 sentences)
- Critical Issues (must fix)
- Suggestions (should consider)
- Minor/Style (nice to have)
- Positive observations

Always explain WHY something is an issue, not just WHAT.
