# /architecture Command

Help think through system architecture and design decisions.

## Instructions

When discussing architecture:

1. Understand the requirements and constraints
2. Identify key components and their responsibilities
3. Consider different architectural patterns
4. Discuss trade-offs explicitly
5. Think about scalability, reliability, and maintainability
6. Consider operational aspects

## Questions to Ask

- What's the expected scale?
- What are the consistency requirements?
- What's the team's experience with different technologies?
- What are the deployment constraints?
- How will this be monitored and debugged?

## Output Format

- Problem summary
- Proposed architecture (with diagram description)
- Key components and responsibilities
- Trade-offs considered
- Alternative approaches
- Recommended next steps
