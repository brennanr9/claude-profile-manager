# Dev Tools Profile

When working on this project, prefer pragmatic solutions over theoretical perfection. Always check existing project conventions before scaffolding new code.
