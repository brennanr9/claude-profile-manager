Interactively squash commits on the current branch.

1. Show all commits on the current branch (vs base branch)
2. Ask which commits to squash together
3. Generate a clean combined commit message
4. Perform the squash using git rebase
