# Code Quality Profile

Prioritize correctness and safety. Flag potential security issues immediately. Prefer explicit types over inference when the type isn't obvious from context.
