After saving changes to a file, check:
- The file still compiles/parses without syntax errors
- Any new exports are properly typed (for TS/JS projects)
- No circular dependencies were introduced
